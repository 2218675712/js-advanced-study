const http = require("http");
const url = require("url");
const app = http.createServer();
app.on("request", (req, res) => {
    res.writeHead(200,{
        'content-type':'text/html;charset=utf-8'
    })
    /*
    * / /index      首页
    * /about        关于我们
    * /news         新闻页面
    * /其他           不存在
    * */
    let {pathname} = url.parse(req.url);
    if (pathname === "/" || pathname === "/index") {
        res.end(`欢迎访问首页`);
    } else if (pathname === "/about") {
        res.end(`欢迎访问关于页面`);
    } else if (pathname === "/news") {
        res.end(`欢迎访问新闻页面`);
    } else {
        res.end(`你访问的页面丢失了`);
    }
});
app.listen(3000);
console.log("服务器启动成功");
