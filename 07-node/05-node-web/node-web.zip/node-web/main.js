const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");
const mime = require("mime");
const app = http.createServer();
app.on("request", (req, res) => {
    let {pathname} = url.parse(req.url);
    if (pathname === "/") {
        pathname = "index.html";
    }
    let absPath = path.join(__dirname, "public", pathname);
    let contentType = mime.getType(absPath);
    fs.readFile(absPath, "utf-8", (err, data) => {
        if (err != null) {
            res.writeHead(404, {
                'content-type': 'text/html;charset=utf-8'
            });
            res.end("你访问的页面不存在");
        }
        res.writeHead(200, {
            'content-type': contentType
        });
        res.end(data);
    })
});
app.listen(3000, function () {
    console.log("服务器启动成功");
});
