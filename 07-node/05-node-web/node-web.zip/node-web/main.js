const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");
const mime = require("mime");
const app = http.createServer();
let contentType = null;
app.on("request", (req, res) => {

    let {pathname} = url.parse(req.url);
    fs.readFile(path.join(__dirname, "public", pathname), "utf-8", (err, data) => {
        contentType = mime.getType(pathname);
        res.writeHead(200, {
            'content-type': `${contentType}`
        });
        res.end(data);
    })
});
app.listen(3000);
console.log("服务器启动成功");
