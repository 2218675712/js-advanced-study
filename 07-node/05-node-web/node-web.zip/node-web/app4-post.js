const http = require('http');
const qs = require('querystring');
const app = http.createServer();
app.on('request', (req, res) => {
    let postData = '';
    req.on('data', (chuck) => {
        postData += chuck;
    })
    req.on('end', () => {
        console.log(postData);
        let {username, password} = qs.parse(postData);
        console.log(username,password);
        res.end(`${username}----${password}`);
    })
});
app.listen(3000);
console.log("服务器启动成功");