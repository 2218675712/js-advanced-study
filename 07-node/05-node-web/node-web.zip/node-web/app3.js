const http = require('http');
// 引入处理url模块
const url = require('url');
const app = http.createServer();
app.on('request', (req, res) => {
    // 第二个参数可以把地址解析成对象形式
    let {query} = url.parse(req.url, true);
    res.end(`${query.username}----${query.password}`);
});
app.listen(3000);
