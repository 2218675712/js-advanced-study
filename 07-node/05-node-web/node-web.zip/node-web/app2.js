/*

// http创建服务器模块
const http = require('http');
// 创建一个服务器
const app = http.createServer();
// 监听客户端请求
app.on('request', (req, res) => {
    res.end("<h1>成功响应</h1>");
})
// 监听端口
app.listen(3000);
console.log("服务器启动成功,请访问http://localhost:3000/");
*/

const http = require('http');

const app = http.createServer(((req, res) => {
    // 请求报文
    console.log(req.headers);
    // 请求地址
    console.log(req.url);
    // 请求方法
    console.log(req.method);
    // 响应
    res.end("<h1>hello</h1>");
}))
// 监听端口
app.listen(3000);


