const express = require("express");
const app = express();

let i=0;
// 中间件,加next可以下次也处理
// 统计get访问次数
app.get("*", (req, res, next) => {
    console.log(++i);
    next();
});
app.get("/req1", (req, res) => {
    res.send();
});
app.listen(3000, () => {
    console.log("服务器成功启动")
});