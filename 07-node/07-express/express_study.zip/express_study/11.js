const express = require("express");
const app = express();
// express.static可以托管静态文件
app.use("/static", express.static("public"));
app.listen(3000, () => {
    console.log("服务器启动成功");
})