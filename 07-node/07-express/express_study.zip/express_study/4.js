const express = require("express");
const bodyParser = require("body-parser");
const app = express();
// 中间件 app.use()    匹配所有请求方式
app.use('/index', (req, res, next) => {
    console.log("111");
    next();
});
// 获取post参数
app.post("/post", (req, res) => {
    console.log(req.body);
    res.send(req.body);
});
app.listen(3000, () => {
    console.log("服务器成功启动");
});