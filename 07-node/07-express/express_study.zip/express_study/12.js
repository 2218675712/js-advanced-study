const express = require("express");
const path = require("path");
const app = express();
// 配置express模板引擎
app.engine("art", require("express-art-template"));
// 设置模板存放目录
app.set("views", path.join(__dirname, "views"));
// 设置模板的默认扩展名
app.set("view engine", "art");
// 设置全局模板引擎
app.locals.msg="hello";
app.get("/index", (req, res) => {/*
    res.render("index", {
        msg: "hello"
    })*/
    res.render("index");
})
app.listen(3000, () => {
    console.log("服务器启动成功");
})