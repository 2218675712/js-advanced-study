const express = require("express");
// 创建路由对象
const home = express.Router();
const app = express();

home.get("/", (req,res) => {
    res.send("来到二级目录首页");
});
home.get("/admin", (req,res) => {
    res.send("来到二级目录管理页面");
});
app.use("/home",home);
app.listen(3000, () => {
    console.log("服务器启动成功");
})