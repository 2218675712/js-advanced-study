const express = require("express");
const app = express();
//拿到这种请求参数
//http://localhost:3000/user/1
app.get("/user/:id",(req,res)=>{
    res.send(req.params);
})
app.listen(3000, () => {
    console.log("服务器启动成功");
})