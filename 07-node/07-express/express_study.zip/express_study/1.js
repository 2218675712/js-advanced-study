const express=require("express");
// 创建网站服务器
const app=express();
app.get("/",(req,res)=>{
    // send()会检测响应内容的类型自动设置状态码
    res.send("hello world");
});
app.listen(3000,()=>{
    console.log("服务器成功启动")
});