const express = require("express");
const bodyParser = require("body-parser");
const app = express();
// 中间件添加模块,处理post请求
app.use(bodyParser.urlencoded({extended: true}));
// 获取get参数
app.get("/req1", (req, res) => {
    console.log(req.query.id);
    res.send(req.query);
});
// 获取post参数
app.post("/post", (req, res) => {
    console.log(req.body);
    res.send(req.body);
});
app.listen(3000, () => {
    console.log("服务器成功启动");
});