const express = require("express");
// 创建路由对象
const home = express.Router();

home.get("/index", (req, res) => {
    res.send("来到二级目录首页");
});
module.exports = home;