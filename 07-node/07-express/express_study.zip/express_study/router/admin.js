const express = require("express");
// 创建路由对象
const admin = express.Router();

admin.get("/admin", (req, res) => {
    res.send("来到二级目录管理页");
});
module.exports = admin;