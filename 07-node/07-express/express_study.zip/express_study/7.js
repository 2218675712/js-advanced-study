const express = require("express");
const fs = require("fs");
const readFile = require("util").promisify(fs.readFile);
const app = express();
app.get("/admin", async (req, res, next) => {
    try {
        let result = await readFile("./11.txt");
        res.send(result.toString());
    } catch (err) {
        next(err);
    }
})
app.use((err, req, res, next) => {
    res.status(500).send(err.message);
});
app.listen(3000, () => {
    console.log("服务器启动成功");
})