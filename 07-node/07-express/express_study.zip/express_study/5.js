const express = require("express");
const bodyParser = require("body-parser");
const app = express();
/*

//维护页面

app.use((req, res, next) => {
    res.send("公司网站正在维护,请明早8早后访问");

});
*/
// 错误处理页面
app.use("/index", (req, res, next) => {
    let isLogin = false;
    if (isLogin) {
        next();
    } else {
        res.send("请登陆后访问主页");
    }
});
app.get("/index",(req,res)=>{
    res.send("你好");
});
app.use((req,res)=>{
    res.status(404).send("你访问的资源不存在");
});
app.listen(3000, () => {
    console.log("服务器成功启动");
});