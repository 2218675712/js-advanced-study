const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const app = express();
app.get("/index", (req, res, next) => {
    fs.readFile("./11.txt", "utf-8", (err, data) => {
        if (err != null) {
            next(err);
        } else {
            res.send(data);
        }
    });
});
app.use((err, req, res, next) => {
    console.log("333");
    res.status(500).send("服务器出现了未知错误");
});
app.listen(3000,()=>{
    console.log("服务器启动成功");
});