## ajax(Asynchronous Javascript And XML)
xml
json

   浏览器-------服务器

   浏览器------ajax------服务器

   ajax 实现页面无刷新更新数据
  注意 ajax运行在网络环境下   