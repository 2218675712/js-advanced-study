const express = require("express");
const app = express();
const path = require("path");
const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// 拦截所有请求
app.use((req, res, next) => {
    // 1.允许哪些客户端访问我
    // * 代表允许所有的客户端访问我
    res.header('Access-Control-Allow-Origin', '*');
    // 自定义请求头
    res.header('Access-Control-Allow-Headers', 'Content-Type, Content-Length, Authorization, Accept, X-Requested-With');
    // 2.允许客户端使用哪些请求方法访问我
    res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
    next();
});
// 加载静态资源
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
    res.send("welcome");
})
app.get("/get", (req, res) => {
    res.send(req.query);
})
app.post("/post", (req, res) => {
    res.send(req.body);
})
app.get("/jsonData", (req, res) => {
    res.send({"age": 20});
})
app.listen(3000, () => {
    console.log("服务器启动成功")
})